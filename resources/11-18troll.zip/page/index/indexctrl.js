myApp.controller('indexCtrl', function($scope){
	
	$scope.$emit("CoverOn",{});
	$scope.$emit("loadingOff",{});

});
