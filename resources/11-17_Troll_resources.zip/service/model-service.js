// 공용데이터 사용용 service

